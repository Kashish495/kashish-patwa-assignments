CREATE TABLE assignment.campaigns(
campaign_id SERIAL primary key,
campaign_name varchar(255),
client_name varchar(255),
campaign_type varchar(255),
start_date date,
end_date date,
target_leads int,
budget int,
status varchar(50)
);
select * from assignment.campaigns;
COPY assignment.campaigns(campaign_name, client_name, campaign_type,start_date, end_date,target_leads,budget, status)
FROM 'C:\Kashish Patwa\Common Assignment\campaigns.csv'
DELIMITER ','
CSV HEADER;
CREATE TABLE assignment.companies(
company_name varchar(255),
industry varchar(255),
company_size varchar(255),
annual_revenue int,
country varchar(255),
state varchar(255),
city varchar(255),
website varchar(255)
);
COPY assignment.companies(company_name, industry, company_size, annual_revenue,country,state,city, website)
FROM 'C:\Kashish Patwa\Common Assignment\companies.csv'
DELIMITER ','
CSV HEADER;
select * from assignment.companies;
alter table assignment.companies
add column company_id serial primary key;
CREATE TABLE assignment.contacts(
contact_id SERIAL primary key,
company_id int,
first_name varchar(255),
last_name varchar(255),
email varchar(255),
phone varchar(255),
job_title varchar(255),
department varchar(255),
seniority_level varchar(255),
linkedin_url varchar(255),
foreign key (company_id) references assignment.companies(company_id)
);
COPY assignment.contacts(company_id, first_name,last_name,email,phone,job_title, department,seniority_level,linkedin_url)
FROM 'C:\Kashish Patwa\Common Assignment\contacts.csv'
DELIMITER ','
CSV HEADER;

create table assignment.leads(
lead_id serial primary key,
contact_id int,
campaign_id int,
lead_source varchar(255),
lead_status varchar(255),
lead_score int,
assigned_to varchar(255),
notes varchar(255),
foreign key (contact_id) references assignment.contacts(contact_id),
foreign key (campaign_id) references assignment.campaigns(campaign_id)
);

COPY assignment.leads(contact_id,campaign_id,lead_source,lead_status,lead_score,assigned_to,notes)
FROM 'C:\Kashish Patwa\Common Assignment\leads.csv'
DELIMITER ','
CSV HEADER;

create table assignment.leads_activities(
activity_id serial primary key,
lead_id int,
activity_type varchar(255),
activity_date timestamp,
activity_description varchar(255),
engagement_score int,
foreign key (lead_id) references assignment.leads(lead_id)
);
COPY assignment.leads_activities(lead_id,activity_type,activity_date,activity_description,engagement_score)
FROM 'C:\Kashish Patwa\Common Assignment\lead_activities.csv'
DELIMITER ','
CSV HEADER;
select * from assignment.companies where industry = 'Technology';
select concat(first_name, last_name) as full_name, email, job_title, company_id from assignment.contacts where seniority_level = 'C-Level' 
select lead_status, count(contact_id) from assignment.leads
group by lead_status
order by count desc;
select * from assignment.contacts where job_title like '%Manager%' or job_title like '%Director%'; 
select ROUND(AVG(lead_score), 2) as avg_score, min(lead_score) as min_score, max(lead_score) as max_score from assignment.leads;
select company_name, annual_revenue, industry from assignment.companies where annual_revenue >= 20000000 and annual_revenue <= 80000000;
SELECT 
   company_name, annual_revenue,
    CASE 
        WHEN annual_revenue> 500000000 THEN 'Large'
        WHEN annual_revenue BETWEEN 100000000 AND 500000000 THEN 'Medium'
        ELSE 'Small'
    END AS size_category;
SELECT
    c.campaign_id,
    c.campaign_name,
    COUNT(l.lead_id) AS total_leads,
    AVG(l.lead_score) AS avg_score,
    COUNT(l.lead_id) FILTER (WHERE l.lead_status = 'Qualified') AS qualified_count
FROM assignment.campaigns c
LEFT JOIN assignment.leads l
    ON c.campaign_id = l.campaign_id
GROUP BY
    c.campaign_id,
    c.campaign_name
ORDER BY
    c.campaign_id;
SELECT
    com.company_id,
    com.company_name,
	COUNT(con.contact_id) as contact_count
FROM assignment.companies AS com
JOIN assignment.contacts AS con
    ON com.company_id = con.company_id
GROUP BY
    com.company_id,
    com.company_name
HAVING COUNT(con.contact_id) > 2;


SELECT
	lead_id,
    lead_score,
    lead_status
FROM assignment.leads
WHERE lead_score > (
    SELECT AVG(lead_score)
    FROM assignment.leads
);

SELECT count(*) as contact_count, split_part(email, '@', 2) AS email_domain
FROM assignment.contacts
group by email_domain;

select campaign_name, start_date, (current_date - start_date) as days_running from assignment.campaigns
where end_date is null;

SELECT
   campaign_id,lead_id, lead_score,
   RANK() OVER (PARTITION BY campaign_id ORDER BY lead_score DESC) AS score_rank
FROM assignment.leads;

select lead_id, lead_status, coalesce(notes, 'No notes') AS notes_display from assignment.leads

update assignment.leads
set lead_status = 'Contacted' where lead_score > 75 and lead_status = 'New';

SELECT
    l.contact_id, l.lead_id,
    concat(c.first_name, c.last_name) as full_name, c.email, c.job_title, c.company_id 
FROM assignment.contacts c
JOIN assignment.leads l
    ON c.contact_id = l.contact_id;


select l.lead_id, ca.first_name, co.company_name, cp.campaign_name, l.lead_score
FROM assignment.leads l
JOIN assignment.contacts ca
  ON l.contact_id = ca.contact_id
JOIN assignment.companies co
  ON ca.company_id = co.company_id
JOIN assignment.campaigns cp
  ON l.campaign_id = cp.campaign_id;

select c.company_name, c.industry, count(l.lead_id) as  total_leads, avg(lead_score) as avg_lead_score
from assignment.companies c join assignment.contacts co on c.company_id = co.company_id
join assignment.leads l on l.contact_id = co.contact_id
group by c.company_name, c.industry
order by total_leads desc;

SELECT
    comp.company_name,
    c1.first_name || ' ' || c1.last_name AS contact1_name,
    c2.first_name || ' ' || c2.last_name AS contact2_name
FROM assignment.contacts c1
JOIN assignment.contacts c2
    ON c1.company_id = c2.company_id
   AND c1.contact_id < c2.contact_id
JOIN assignment.companies comp
    ON c1.company_id = comp.company_id
ORDER BY comp.company_name;

SELECT c.campaign_name, COUNT(l.lead_id) AS lead_count
FROM assignment.campaigns c JOIN assignment.leads l
ON c.campaign_id = l.campaign_id
GROUP BY c.campaign_name
HAVING COUNT(l.lead_id) > (
	SELECT AVG(lead_cnt) 
	FROM (
		SELECT COUNT(*) AS lead_cnt 
		FROM assignment.leads 
		GROUP BY campaign_id
	)
);	




SELECT l.lead_id, COUNT(a.activity_id) AS total_activities, SUM(a.engagement_score) AS total_engagement_score, MAX(a.activity_date) AS last_activity_date
FROM assignment.leads l LEFT JOIN assignment.leads_activities a
ON l.lead_id = a.lead_id
GROUP BY l.lead_id
ORDER BY total_engagement_score DESC;

SELECT c.campaign_name, c.budget, COUNT(l.lead_id) AS total_lead, (c.budget/COUNT(l.lead_id)) AS cost_per_lead
FROM assignment.campaigns c JOIN assignment.leads l
ON c.campaign_id = l.campaign_id
GROUP BY c.campaign_name, c.budget
HAVING c.campaign_name IN (
	SELECT campaign_name 
	FROM campaigns
	WHERE status = 'Active' OR status = 'Completed'
);



FROM campaigns c JOIN leads l
ON c.campaign_id = l.campaign_id
GROUP BY c.campaign_name, c.budget
HAVING c.campaign_name IN (
	SELECT campaign_name 
	FROM campaigns
	WHERE status = 'Active' OR status = 'Completed'
);

SELECT * FROM assignment.companies;
SELECT * FROM assignment.contacts;
SELECT * FROM assignment.leads;
SELECT c1.company_name, (c2.first_name || ' ' || c2.last_name) AS contact_name, c2.job_title, l.lead_score
FROM assignment.companies c1 JOIN contacts c2 ON c1.company_id = c2.company_id 
JOIN assignment.leads l ON l.contact_id = c2.contact_id 
WHERE c1.industry = 'Technology' 
	AND c2.seniority_level = 'C-Level' 
	AND l.lead_score > 75 
ORDER BY l.lead_score DESC;
